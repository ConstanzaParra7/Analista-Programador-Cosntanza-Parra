/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemaventasteatromoro;
import java.util.Scanner;

/**
 *
 * @author conam
 */

//punto de entrada de mi programa, desde aca inicializan las clases principales 
public class Main {
            
            public static void main (String[] args) {
                
                Scanner scanner = new Scanner(System.in);
                Teatro teatro = new Teatro(); //tiene todas las entradas disponibles
                Carrito carrito = new Carrito(); //almacena las compras del usuario
                
                //Ingreso de datos del usuario
                System.out.println("Ingrese su nombre:");
                String nombre = scanner.nextLine();
                
                
                System.out.println("Ingrese su edad:");
                int edad = scanner.nextInt();
                scanner.nextLine();
                
                //Descuentos aplicados por edad
                double descuentoEdad = 0.0;
                if (edad < 18) {
                    System.out.println("Aplica descuento de estudiante 10%");
                    descuentoEdad = 0.10;
                }else if (edad>65) {
                    System.out.println("Aplica descuento de Adulto Mayor 15%");
                    descuentoEdad = 0.15;
                }
                
                //Bucle principal del menú,se repetira hasta que se cumpla el salir
                boolean salir = false;
                while (!salir) {
                    System.out.println("\n MENÚ PRINCIPAL:");
                    System.out.println("1. Ver entradas disponibles");
                    System.out.println("2. Ver promociones");
                    System.out.println("3. Buscar entrada por número y ubicación");
                    System.out.println("4. Borrar entrada del carrito");
                     System.out.println("5. Ver carrito y pagar");
                    System.out.println("6. Salir");
                    
                    System.out.println("Seleccione una opcción: ");
                    int opcion = scanner.nextInt();
                    scanner.nextLine();
                    
                    switch (opcion) {
                        case 1:
                            teatro.mostrarEntradasDisponibles(); //muestra todas las entradas disponibles
                            System.out.println("¿Desea comprar una entrada? (si/no): ");
                            String respuesta = scanner.nextLine();
                            if (respuesta.equalsIgnoreCase("si")) {
                                System.out.println("ngresa la ubicación (VIP, Platea Alta, Platea Baja, Palco):");
                                String ubicacion = scanner.nextLine();
                                teatro.mostrarPorUbicacion(ubicacion);
                                
                                System.out.println("Ingresa el número de la entrada que quieres comprar");
                                int numeroEntrada = scanner.nextInt();
                                scanner.nextLine();
                                
                                Entrada entrada = teatro.buscarEntrada(numeroEntrada, ubicacion);
                                if (entrada != null) {
                                    entrada.aplicarDescuento(descuentoEdad);
                                    carrito.agregarEntrada(entrada);
                                }else {
                                    System.out.println("Entrada no disponible.");
                                }
                            }
                            break;
                            
                        case 2:
                            //ver promociones
                            Promociones.mostrarPromociones(); //llama al método estático de la clase promociones para que se vean
                            break;
                            
                        case 3:
                            //buscar entrada por numero y ubicación
                            System.out.print("Ingrese el número de entrada: ");
                            int num = scanner.nextInt();
                            scanner.nextLine();
                            System.out.println("Ingrese Ubicación: ");
                            String ubi = scanner.nextLine();
                            
                            Entrada encontrada = teatro.buscarEntrada(num, ubi);
                            if (encontrada != null) {
                                System.out.println("Entrada encontrada");
                                System.out.println(encontrada);
                            }else {
                                System.out.println("Entrada no disponible");
                            }
                            break;
                            
                        case 4:
                            //borrar entrada del carrito
                            System.out.print("Ingrese el numero de la entrada a eliminar del carrito: ");
                            int numEliminar = scanner.nextInt();
                            carrito.eliminarEntrada(numEliminar); //llama al metodo eliminarEntrada para eliminarla
                            break;
                            
                        case 5:
                            //ver carrito y pagar
                            System.out.println("\n === RESUMEN FINAL: ===");
                            carrito.mostrarResumen();
                            break;
                            
                        case 6: 
                            //cambia la variable a verdadera para que se salga del bucle
                            salir = true;
                            System.out.println("Gracias por preferir el TEATRO MORO, hasta pronto!");
                            break;
                            
                        default:
                            System.out.println("Opción inválida, intente nuevamente");
                    }
                }
            scanner.close();
               
            }
}