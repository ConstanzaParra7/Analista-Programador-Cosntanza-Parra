/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemaventasteatromoro;
/**
 *
 * @author conam
 */

//
public class Promociones {
    public static void mostrarPromociones() {
        System.out.println("============ PROMOCIONES DISPONIBLES ============");
        System.out.println ("1 - 2X1 en entradas para pajeras");
        System.out.println("2 - 5% de descuento si comrpras 5 entradas o más");
        System.out.println("====== Descuentos automáticos al finalizar tu compra======");
     }
}

