package sistemaventasteatromoro;

import java.util.ArrayList;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author conam
 */

// Clase diseñada para representar el carrito de compras en el sistema de ventas, busca poder agregar, eliminar y mostrar un resumen del carrito
     public class Carrito {
            private final ArrayList<Entrada> entradas; //lista (array) creada para almacenar los datos de Entrada que se añadan al carrito
                
            public Carrito () {
                this.entradas = new ArrayList <>(); //le asigno una lista vacía de entradas al carrito
            }
            
            //metodo creado para agregar entradas al carrito(que esta vacío)
           public void agregarEntrada (Entrada entrada) { 
               if (entrada != null && entrada.estaDisponible()) { //condiciones para agregar al carrito
                   entradas.add(entrada); 
                   entrada.vender();
                   System.out.println("Entrada agregada al carrito."); 
               
                }else {
                   System.out.println(" No se pudo agregar la entrada.");
                }
           }
               
                    
                
            public void eliminarEntrada (int numero) {
                boolean eliminada = false;
                for (int i=0; i< entradas.size(); i++) {
                    if (entradas.get(i).getNumero() == numero){ //recorre lista entradas bsucnado alguina con el numero que ingreso
                        entradas.get(i).vender(); //sila encuentra cambia el estado a disponible
                        entradas.remove(i); //eliminar la entrada de la lista de entradas
                        System.out.println("Entrada elimidada del carrito");
                        eliminada = true; //cambia la variable eliminada para detener el bucle con break
                        break;
                    }
                }  
                if (!eliminada) { //si eliminada sigue siendo fasa, no cambia nada
                    System.out.println("Entrada no encontrada en el carrito");
                }
            }
                //ene ste método busco unr esumen general para el usuario
            public void mostrarResumen() { 
                if (entradas.isEmpty()) { //verifica con el metodo isEmpty para ver si el carrito está vacío
                    System.out.println("El carrito está vacío.");
                    return; 
                }
                
                int subtotal = 0;
                System.out.println("Entradas en tu carrito:"); //suma todas las entradas agregadas a la lista
                for (Entrada e : entradas) {
                    System.out.println(e);
                    subtotal += e.getPrecio();
                    }
                
                double descuentoPromo = 0.0;
                
                //aplicación de descuentos
                if (entradas.size()  >= 2 && entradas.size() % 2 == 0) {
                    descuentoPromo += entradas.get(0).getPrecio(); //2x1 en una entrada
                }
                
                if (entradas.size()>= 5) {
                    descuentoPromo += subtotal * 0.05; //5%por 5 o más
                }
                
                //indico total con descuento aplicado
                double total = subtotal - descuentoPromo;
                System.out.println("Subtotal: $" + subtotal);
                System.out.println("Descuentos aplicados: $" + (int)descuentoPromo);
                System.out.println("TOTAL A PAGAR: $" + (int)total);
                
                }
            }

