/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemaventasteatromoro;

import java.util.ArrayList;

/**
 *
 * @author conam
 */
 public class Teatro {
    private ArrayList<Entrada> entradas; //creo lista que almacena todas las entradas del teatro
    private int contadorEntradas; //le asigna un numero unico a cada entrada generada, va a incrementr cuandos e cree una nueva
                
    public Teatro() {
        this.entradas = new ArrayList <>(); //listfa de entradas vacía
        this.contadorEntradas = 1; 
        generarEntradas(); //crea conjunto inicial de entradas
    }
    
    //indico cuales seran las entradas disponibles segunparámetros: sector, su precio y cantidad
    private void generarEntradas() {
        agregarEntradas("VIP", 30000, 10);
        agregarEntradas("Platea Alta", 18000, 15);
        agregarEntradas("Platea Baja", 15000, 20);
        agregarEntradas("Palco", 13000, 25);
    }
                    
    private void agregarEntradas(String ubicacion, int precio, int cantidad) { //creado para añadir entradas a la lista entradas
        for (int i = 0; i < cantidad; i++) { 
            entradas.add(new Entrada(contadorEntradas++, ubicacion, precio)); //se crean la cantidad de entradas generadas
        }
    }
                    
    public void mostrarEntradasDisponibles() {
        System.out.println("Entradas disponibles;");
        for (Entrada e : entradas) { //recorre la lista entradas con el bucle for
            if (e.estaDisponible()) { //por cada entrada verifica si estqa disponible
                System.out.println(e);
            }
        }
    }
                    
    public Entrada buscarEntrada(int numero, String ubicacion)  {
        for (Entrada e : entradas) {
            //por cada entrada se verifica si el numero coincide y la ubicación, tambien si está o no disponible
            if (e.getNumero() == numero && e.getUbicacion().equalsIgnoreCase(ubicacion)&& e.estaDisponible()) {
                return e;
            }
        }
        return null;
    }
                    
    public void mostrarPorUbicacion (String ubicacion) {
        System.out.println("Entradas disponibles en "+ ubicacion + ":");
            for (Entrada e : entradas) { //recorre lista entradas con el bucle for
                if (e.estaDisponible() && e.getUbicacion().equalsIgnoreCase(ubicacion)) {
                    System.out.println(e);
                }
            }
        }
    }           