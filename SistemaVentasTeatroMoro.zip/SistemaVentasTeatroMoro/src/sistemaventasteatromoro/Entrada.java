/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sistemaventasteatromoro;
/**
 *
 * @author conam
 */
     //CLASE ENTRADA: creada para modelar las entradas disponibles para comprar
        
public class Entrada {
    private String ubicacion; //ubicación de la entrada segun: VIP, Platea baja, Platea alta, Palco.
    private int numero, precio; //numero= identifica la entrada, precio=valor de la entrada segun ubicación
    private boolean disponible; //booleano que ayuda a identificar si esta disponible la entrada o no.
            
    //Constructor inicializa las nuevas entradas
    public Entrada (int numero, String ubicacion, int precio) {
        this.numero = numero;
        this.ubicacion = ubicacion;
        this.precio = precio; //precio inicial
        this.disponible = true; //estara disponible hasta que alguien la compre
    }
     
    //Metodo GETTER= lo use para poder acceder a la clase y sus atributos
    public int getNumero () { //devuelve el numero único de la entrada
        return numero;
    }
            
    public String getUbicacion () { //devuelve ubicacion de la entrada
        return ubicacion;
    }
            
    public int getPrecio () { //devuelve precio actual de la entrada
        return precio;
    }
            
    public boolean estaDisponible() { //devuelve si esta disponible (true) o si no (false)
        return disponible;
    }
            
    public void vender() { //marca una entrada como vendida, actualiza al venderse
        this.disponible = false; //cambiara el estado a no disponible, this hace referencia a la variable de instancia de la clase
    }
            
    public void aplicarDescuento (double porcentaje) { //reduzco el precio con una función de descuento
        this.precio = (int)(precio* (1 - porcentaje));
    }
       
            
            
    @Override //indica que se esta sobreescribiendo el metodo en la clase
        public String toString () { //imprime en pantalla una descripción legible al convertirlo en texto
            return "Entrada # " + numero + " | " + ubicacion + " | " + " | $" + precio + " | " + (disponible ? "Disponible" : "VENDIDA");    
                      
        }
    }
            
